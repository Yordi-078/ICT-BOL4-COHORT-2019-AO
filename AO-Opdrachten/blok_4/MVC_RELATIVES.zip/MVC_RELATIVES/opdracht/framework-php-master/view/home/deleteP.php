<div class="text-center">
<p> Weet je zeker dat je het wilt verwijderen?</p>
 <a class="btn btn-info" href="<?= URL ?>/home/index">nee</a>
 <a class="btn btn-danger" href="<?= URL ?>/home/destroyP/<?= $id['id'] ?>">ja</a>
 </div>