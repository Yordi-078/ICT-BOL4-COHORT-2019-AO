<p> Weet je zeker dat je het wilt verwijderen?</p>
 <a href="<?= URL ?>/home/index"><button>nee</button></a>
 <a href="<?= URL ?>/home/destroyP/<?= $id['id'] ?>"><button>ja</button></a>