<h1 class="text-center"> voeg een paard toe</h1>
<form name ="create" method= "post" action="<?=URL?>/home/storeP">
name:<input type= "text" class="form-control" name="name" required>
leeftijd:<input type= "number" class="form-control" name="leeftijd" required>
lengte in cm:<input type= "number" class="form-control" name="lengte" required>

<input class="btn btn-primary" type="submit">
</form>
<br>
<div class="card-header"  >
<p>Of een dier een paard of pony is, is bij onze manege afhankelijk van de gemiddelde volwassen schofthoogte die hoort bij het ras waartoe het dier behoort. Tot 147,5 cm gaat het om een pony ras. Ik weet dat dit door ruiters die zich bezighouden met de springsport per individueel dier wordt bekeken, maar dat is voor het fokken simpelweg niet praktisch. Er bestaat een lijst waarop per ras de gemiddelde schofthoogte staat vermeld.</p>
</div>


