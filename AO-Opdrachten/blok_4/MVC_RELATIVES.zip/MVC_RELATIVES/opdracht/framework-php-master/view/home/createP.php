<h1> voeg een paard toe</h1>
<form name ="create" method= "post" action="<?=URL?>/home/storeP">
name:<input type= "text" name="name">
leeftijd:<input type= "number" name="leeftijd">
ras:<input type= "text" name="ras">
springsport:<input type= "text" name="springsport">

<input type="submit">

</form>