<div class="text-center py-3">@Yordi van Berkum
    <a href="<?= URL ?>home/index"> Home</a>
  </div>