<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<title>Paarden</title>	
	<link rel="stylesheet" href="<?= URL ?>">
</head>
<body>
<div class="row">
	<div class="col text-center">
		<a class="btn btn-primary center-block" href="<?= URL ?>home/index">Home</a>
		<a class="btn btn-primary center-block" href="<?= URL ?>student/index">Bezoekers</a>
	</div>
	</div>
