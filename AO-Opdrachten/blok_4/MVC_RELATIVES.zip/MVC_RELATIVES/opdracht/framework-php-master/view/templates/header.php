<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Paarden</title>	
	<link rel="stylesheet" href="<?= URL ?>">
</head>
<body>
	<nav>
	<ul>
		<li><a href="<?= URL ?>home/index">Home</a></li>
		<li><a href="<?= URL ?>student/index">Bezoekers</a></li>
	</ul>
	</nav>
