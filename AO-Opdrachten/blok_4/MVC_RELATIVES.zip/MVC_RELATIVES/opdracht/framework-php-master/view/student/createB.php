<h1> voeg een medewerker toe</h1>
<form name ="create" method= "post" action="<?=URL?>/student/storeB">
name:<input type= "text" name="name">
adres:<input type= "text" name="adres">
telefoonnummer:<input type= "text" name="telefoonnummer">
identificatienummer:<input type= "number" name="identificatienummer">

<input type="submit">

</form>