
<div class="text-center">
<p> Weet je zeker dat je <?= $id['name'] ?> wilt verwijderen?</p>
 <a class="btn btn-info" href="<?= URL ?>/student/index">nee</a>
 <a class="btn btn-danger" href="<?= URL ?>/student/destroyB/<?= $id['id'] ?>">ja</a>
 </div>

