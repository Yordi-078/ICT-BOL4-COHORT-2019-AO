<p> Weet je zeker dat je <?= $id['name'] ?> wilt verwijderen?</p>
 <a href="<?= URL ?>/student/index"><button>nee</button></a>
 <a href="<?= URL ?>/student/destroyB/<?= $id['id'] ?>"><button>ja</button></a>

