<h1> voeg een medewerker toe</h1>
<form name ="create" method= "post" action="<?=URL?>/employee/store">
name:<input type= "text" name="name">
age:<input type= "number" name="age">
<input type="submit">

</form>