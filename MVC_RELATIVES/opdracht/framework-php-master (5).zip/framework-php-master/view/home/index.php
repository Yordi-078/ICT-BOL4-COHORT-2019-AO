<div class="container">
 <h1>Welkom bij het php-framework.</h1>
 <p>Je bent nu in home/index.</p>
</div>
